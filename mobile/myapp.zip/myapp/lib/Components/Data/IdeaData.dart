class IdeaData{
  int ideaId = 0;
  int replyTo = 0;
  String userId = "";
  String userName = "";
  String userAvatar = "";
  int timestamp = 0;
  String subject = "";
  String content = "";
  String attachment = "";
  int numLikes = 0;
  int numDislikes = 0;
  List<IdeaData> comments = [];
}